=== Plugin Name ===
Contributors: amarinfotech (info@amarinfotech.com)
Donate link: http://amarinfotech.com/
Tags: comments, Facebook login, download
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 3.4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will restrict user from download extensions file in content without loginto facebook.

== Description ==

Amarinfotech Downlaod with FB Connect have Facebook sign up functionality to Wordpress using the
Facebook Connect APIs and Facebook SDK.  Features include:

 * Without loginto Facebook it will restric files for download from post or page
 * Register user to your blog
 * Check for the permission of facebook user. If user delete your application from Fb it will also delete user from your blog.
 * Take permission for extended permission of user like post on users wall
 * Show FB user information like avtar nad username with FB page link 
 * Publish comments to the newsfeed
 * Comment avatars display Facebook profile photos

== Installation ==

1. Copy the plugin to wp-content/plugins/amr-fbdownload under the
 Wordpress installation.
 2. In the Wordpress Admin panel, visit the plugins page and Activate the plugin.
 3. Visit the settings page and select "Facebook Connect".  Follow the
 given instructions to configure the plugin and obtain a Facebook API key.
 4. Provide extension to restrict from download
 
 * There are no seeting required for this plugin you jut have to install it and it's done. No worry about short code and template changes.

 * Note that the fbc_comment_login function should be called *regardless*
of whether the user is currently logged into WP or not.  It will DTRT.

 * See config.php and the Settings page for more configuration and
customization options.

== Frequently Asked Questions ==

No faqs right now

== Screenshots ==

1. Admin panel setting for Facebook API.
2. Front side user view before login into facebook
3. Frint side user view after login into facebook

== Changelog ==

= 1.0 =
* Stable version for wordpress 3.0 upto 3.4.1.

== Arbitrary section ==

This plugin is developed by Amarinfotech for filtering post or page content and restrict user to download that files without sign into facebook.

== A brief Markdown Example ==

It will filter your content and find the file link which hase extension 
specified in admin setting page. It will restrict user to download the file.
To download file user have to loginto facebook account first time if user accept 
post to wall permission and other permission plugin will automatically post on facebook
user's wall. If user delete application from facebook then blog will automatically delete
that user from blog.

It ill generate a section for connect befor download the file where user can login into 
his/her facebook account.

== Upgrade Notice == 

This is stable version. We will work more for this.